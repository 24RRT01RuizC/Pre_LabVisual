﻿namespace Pre_Lab_RodrigoRuiz_VC_32
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            imgCol = new DataGridViewImageColumn();
            Nombre = new DataGridViewTextBoxColumn();
            Grado = new DataGridViewTextBoxColumn();
            Seccion = new DataGridViewTextBoxColumn();
            Clases = new DataGridViewCheckBoxColumn();
            Numero_de_teléfono = new DataGridViewTextBoxColumn();
            Correo = new DataGridViewTextBoxColumn();
            No_matri = new DataGridViewTextBoxColumn();
            Cic_acad = new DataGridViewTextBoxColumn();
            Link = new DataGridViewLinkColumn();
            txtNombre = new TextBox();
            txtGrado = new TextBox();
            txtSeccion = new TextBox();
            txtTelefono = new TextBox();
            txtCorreo = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label9 = new Label();
            label10 = new Label();
            txtCiclo = new TextBox();
            txtMatricula = new TextBox();
            btnAgregar = new Button();
            btnEditar = new Button();
            btnBorrar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { ID, imgCol, Nombre, Grado, Seccion, Clases, Numero_de_teléfono, Correo, No_matri, Cic_acad, Link });
            dataGridView1.Location = new Point(-2, -1);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1426, 188);
            dataGridView1.TabIndex = 0;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.Width = 125;
            // 
            // imgCol
            // 
            imgCol.HeaderText = "Usuario";
            imgCol.Image = Properties.Resources._3171065;
            imgCol.MinimumWidth = 6;
            imgCol.Name = "imgCol";
            imgCol.Width = 125;
            // 
            // Nombre
            // 
            Nombre.HeaderText = "Nombre";
            Nombre.MinimumWidth = 6;
            Nombre.Name = "Nombre";
            Nombre.Resizable = DataGridViewTriState.True;
            Nombre.SortMode = DataGridViewColumnSortMode.NotSortable;
            Nombre.Width = 125;
            // 
            // Grado
            // 
            Grado.HeaderText = "Grado";
            Grado.MinimumWidth = 6;
            Grado.Name = "Grado";
            Grado.Width = 125;
            // 
            // Seccion
            // 
            Seccion.HeaderText = "Seccion";
            Seccion.MinimumWidth = 6;
            Seccion.Name = "Seccion";
            Seccion.Width = 125;
            // 
            // Clases
            // 
            Clases.HeaderText = "Mayor de 18 años";
            Clases.MinimumWidth = 6;
            Clases.Name = "Clases";
            Clases.Width = 125;
            // 
            // Numero_de_teléfono
            // 
            Numero_de_teléfono.HeaderText = "Numero_de_teléfono";
            Numero_de_teléfono.MinimumWidth = 6;
            Numero_de_teléfono.Name = "Numero_de_teléfono";
            Numero_de_teléfono.Width = 125;
            // 
            // Correo
            // 
            Correo.HeaderText = "Correo electrónico";
            Correo.MinimumWidth = 6;
            Correo.Name = "Correo";
            Correo.Width = 125;
            // 
            // No_matri
            // 
            No_matri.HeaderText = "Numero de matrícula";
            No_matri.MinimumWidth = 6;
            No_matri.Name = "No_matri";
            No_matri.Width = 125;
            // 
            // Cic_acad
            // 
            Cic_acad.HeaderText = "Ciclo académico actual";
            Cic_acad.MinimumWidth = 6;
            Cic_acad.Name = "Cic_acad";
            Cic_acad.Width = 125;
            // 
            // Link
            // 
            Link.HeaderText = "Link Don Bosco";
            Link.MinimumWidth = 6;
            Link.Name = "Link";
            Link.Width = 125;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(165, 230);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(199, 27);
            txtNombre.TabIndex = 2;
            // 
            // txtGrado
            // 
            txtGrado.Location = new Point(165, 292);
            txtGrado.Name = "txtGrado";
            txtGrado.Size = new Size(199, 27);
            txtGrado.TabIndex = 3;
            // 
            // txtSeccion
            // 
            txtSeccion.Location = new Point(165, 354);
            txtSeccion.Name = "txtSeccion";
            txtSeccion.Size = new Size(199, 27);
            txtSeccion.TabIndex = 4;
            // 
            // txtTelefono
            // 
            txtTelefono.Location = new Point(165, 416);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(199, 27);
            txtTelefono.TabIndex = 5;
            // 
            // txtCorreo
            // 
            txtCorreo.Location = new Point(165, 478);
            txtCorreo.Name = "txtCorreo";
            txtCorreo.Size = new Size(199, 27);
            txtCorreo.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(59, 233);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 7;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(65, 295);
            label2.Name = "label2";
            label2.Size = new Size(54, 20);
            label2.TabIndex = 8;
            label2.Text = "Grado ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(59, 357);
            label3.Name = "label3";
            label3.Size = new Size(60, 20);
            label3.TabIndex = 9;
            label3.Text = "Seccion";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 419);
            label4.Name = "label4";
            label4.Size = new Size(144, 20);
            label4.TabIndex = 10;
            label4.Text = "Numero de teléfono";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(17, 481);
            label5.Name = "label5";
            label5.Size = new Size(125, 20);
            label5.TabIndex = 11;
            label5.Text = "Correo eletrónico";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(432, 297);
            label9.Name = "label9";
            label9.Size = new Size(163, 20);
            label9.TabIndex = 18;
            label9.Text = "Ciclo academico actual";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(437, 233);
            label10.Name = "label10";
            label10.Size = new Size(150, 20);
            label10.TabIndex = 17;
            label10.Text = "Numero de Matricula";
            // 
            // txtCiclo
            // 
            txtCiclo.Location = new Point(593, 292);
            txtCiclo.Name = "txtCiclo";
            txtCiclo.Size = new Size(199, 27);
            txtCiclo.TabIndex = 13;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(593, 230);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(199, 27);
            txtMatricula.TabIndex = 12;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(437, 357);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(158, 59);
            btnAgregar.TabIndex = 19;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += button1_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(634, 357);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(158, 59);
            btnEditar.TabIndex = 20;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += button2_Click;
            // 
            // btnBorrar
            // 
            btnBorrar.Location = new Point(535, 422);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(158, 59);
            btnBorrar.TabIndex = 21;
            btnBorrar.Text = "Borrar";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += button3_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1427, 592);
            Controls.Add(btnBorrar);
            Controls.Add(btnEditar);
            Controls.Add(btnAgregar);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(txtCiclo);
            Controls.Add(txtMatricula);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtCorreo);
            Controls.Add(txtTelefono);
            Controls.Add(txtSeccion);
            Controls.Add(txtGrado);
            Controls.Add(txtNombre);
            Controls.Add(dataGridView1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox txtNombre;
        private TextBox txtGrado;
        private TextBox txtSeccion;
        private TextBox txtTelefono;
        private TextBox txtCorreo;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label9;
        private Label label10;
        private TextBox txtCiclo;
        private TextBox txtMatricula;
        private Button btnAgregar;
        private Button btnEditar;
        private Button btnBorrar;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewImageColumn imgCol;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Grado;
        private DataGridViewTextBoxColumn Seccion;
        private DataGridViewCheckBoxColumn Clases;
        private DataGridViewTextBoxColumn Numero_de_teléfono;
        private DataGridViewTextBoxColumn Correo;
        private DataGridViewTextBoxColumn No_matri;
        private DataGridViewTextBoxColumn Cic_acad;
        private DataGridViewLinkColumn Link;
    }
}