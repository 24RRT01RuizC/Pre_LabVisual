﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pre_Lab_RodrigoRuiz_VC_32
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView1.Rows.Add();
//Si hay una nueva linea se agreaga 1+
            dataGridView1.Rows[rowIndex].Cells[0].Value = rowIndex + 1; 
//Imagen de usuario
            dataGridView1.Rows[rowIndex].Cells[1].Value = Properties.Resources._3171065; 
//Texto pasado a tabla
            dataGridView1.Rows[rowIndex].Cells[3].Value = txtGrado.Text;
//Texto pasado a tabla
            dataGridView1.Rows[rowIndex].Cells[4].Value = txtSeccion.Text;
//Se usa para que el usuario ponga si es o no mayor a 18
            dataGridView1.Rows[rowIndex].Cells[5].Value = false; 
//Texto pasado a tabla
            dataGridView1.Rows[rowIndex].Cells[6].Value = txtTelefono.Text;
//Texto pasado a tabla
            dataGridView1.Rows[rowIndex].Cells[7].Value = txtCorreo.Text;
//Texto pasado a tabla
            dataGridView1.Rows[rowIndex].Cells[8].Value = txtMatricula.Text;
//Texto pasado a tabla
            dataGridView1.Rows[rowIndex].Cells[9].Value = txtCiclo.Text;
//Link para que se vea en tabla
            dataGridView1.Rows[rowIndex].Cells[10].Value = "https://donbosco.com"; 
        
    }

    private void Form2_Load(object sender, EventArgs e)
        {
//Donde tiene que aparecer la imagen
            ((DataGridViewImageColumn)dataGridView1.Columns[1]).Image = Properties.Resources._3171065;
//Buscar la imagen en resources
            imgCol.Image = Properties.Resources._3171065;
//Colocar bien la imagen
            imgCol.ImageLayout = DataGridViewImageCellLayout.Zoom; 
//Darle un tamaño a la imagen
            dataGridView1.Columns[1].Width = 70; 

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null) //Para obtener las celdas de la tabla
            {
                DataGridViewRow row = dataGridView1.CurrentRow;
                row.Cells[2].Value = txtNombre.Text;
                row.Cells[3].Value = txtGrado.Text;
                row.Cells[4].Value = txtSeccion.Text;
                row.Cells[6].Value = txtTelefono.Text;
                row.Cells[7].Value = txtCorreo.Text;
                row.Cells[8].Value = txtMatricula.Text;
                row.Cells[9].Value = txtCiclo.Text;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Para limpiar toda la tabla
            if (dataGridView1.CurrentRow != null)
            {
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
            }
        }
    }
}
