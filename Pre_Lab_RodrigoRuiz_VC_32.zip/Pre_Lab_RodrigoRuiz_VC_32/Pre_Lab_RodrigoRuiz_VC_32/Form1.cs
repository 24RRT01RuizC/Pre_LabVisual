namespace Pre_Lab_RodrigoRuiz_VC_32
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
//Declaracion de los textbox
            string usuario = txtUsuario.Text; 
            string contrase�a = txtContrase�a.Text;

            if (contrase�a == "12345")
            {
                // Para que el message box tenga cierto dise�o y diga si es correcta
                MessageBox.Show("Bienvenido " + usuario + "", "Contrase�a Correcta", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                // Para en caso que sea correcta dirigirse al nuevo correo
                Form2 messi = new Form2();
                messi.Show();
                this.Hide();
            }
            else
            {
                //Message box de dise�o y tambien que diga lo que pone entre comillas en caso que sea equivocada la contrase�a
                MessageBox.Show("Contrase�a incorrecta \nPrueba con el boton contrase�a para saberla", "Error de acceso", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_contrase�a_Click(object sender, EventArgs e)
        {
            //Pista para la contrase�a
            MessageBox.Show("La contrase�a es 12345");

        }
    }
}

