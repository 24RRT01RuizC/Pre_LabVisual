﻿namespace Pre_Lab_RodrigoRuiz_VC_32
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtContraseña = new TextBox();
            btn_Login = new Button();
            btn_contraseña = new Button();
            txtUsuario = new TextBox();
            label1 = new Label();
            label2 = new Label();
            lblMensaje = new Label();
            SuspendLayout();
            // 
            // txtContraseña
            // 
            txtContraseña.Location = new Point(188, 193);
            txtContraseña.Name = "txtContraseña";
            txtContraseña.PasswordChar = '*';
            txtContraseña.Size = new Size(308, 27);
            txtContraseña.TabIndex = 0;
            // 
            // btn_Login
            // 
            btn_Login.Location = new Point(99, 285);
            btn_Login.Name = "btn_Login";
            btn_Login.Size = new Size(139, 43);
            btn_Login.TabIndex = 1;
            btn_Login.Text = "Entrar";
            btn_Login.UseVisualStyleBackColor = true;
            btn_Login.Click += btn_Login_Click;
            // 
            // btn_contraseña
            // 
            btn_contraseña.Location = new Point(485, 285);
            btn_contraseña.Name = "btn_contraseña";
            btn_contraseña.Size = new Size(139, 43);
            btn_contraseña.TabIndex = 2;
            btn_contraseña.Text = "Contraseña";
            btn_contraseña.UseVisualStyleBackColor = true;
            btn_contraseña.Click += btn_contraseña_Click;
            // 
            // txtUsuario
            // 
            txtUsuario.Location = new Point(188, 97);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(308, 27);
            txtUsuario.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(313, 58);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 4;
            label1.Text = "Usuario";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(301, 158);
            label2.Name = "label2";
            label2.Size = new Size(83, 20);
            label2.TabIndex = 5;
            label2.Text = "Contraseña";
            // 
            // lblMensaje
            // 
            lblMensaje.AutoSize = true;
            lblMensaje.Location = new Point(513, 196);
            lblMensaje.Name = "lblMensaje";
            lblMensaje.Size = new Size(0, 20);
            lblMensaje.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(699, 393);
            Controls.Add(lblMensaje);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtUsuario);
            Controls.Add(btn_contraseña);
            Controls.Add(btn_Login);
            Controls.Add(txtContraseña);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtContraseña;
        private Button btn_Login;
        private Button btn_contraseña;
        private TextBox txtUsuario;
        private Label label1;
        private Label label2;
        private Label lblMensaje;
    }
}
